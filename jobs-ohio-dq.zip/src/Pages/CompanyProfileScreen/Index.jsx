import React from "react";
import Layout from "../../Components/layout";
import "./Style.css";
const AILeads = () => {
  return (
    <>
      <Layout>
        <div className="child-section-of-everypage"></div>
      </Layout>
    </>
  );
};
export default AILeads;
